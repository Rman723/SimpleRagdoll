local player = GetPlayerPed(-1)

Citizen.CreateThread(function()
    while true do 
        Citizen.Wait(0)

        if IsControlJustReleased(1, 182) then
			SetPedToRagdoll(player, 1000, 1000, 0, 0, 0, 0)

            end
        end
    end
end)


